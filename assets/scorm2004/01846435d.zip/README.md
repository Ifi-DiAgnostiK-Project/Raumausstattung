<!--
author:    Hilke Domsch; Anne-Kristin Schmidt; Kay Deblitz
email:     hilke.domsch@gkz-ev.de
date:      2026-05-08
version:   0.0.1

narrator:  Deutsch Male
language:  de

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/raumausstattung-polster-naehmaschine
icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/e6a2940f3609f54a920128b6d84f56e321581cf2.jpg

title:     Polster-Nähmaschine GR-06 | R3-03 Grundkurs-Überprüfungsfragen
comment:   Überprüfungsfragen Kurs GR-06 Grundstufe Nähmaschine | Kurs R3-03 Polstertechniken
attribute: title image, by Kay Deblitz HWK Dresden
tags:      Raumausstatter,
           Polstern,
           Nähmaschine,
           Nähen,
           Industrieschnellnäher

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Textilpflegesymbole/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Bildersammlung/refs/heads/main/makros.md
-->

# Die Polster-Nähmaschine

Die Polster<!-- style="font-weight: bolder; font-size: 11pt; color: green;"-->-<!-- style="font-weight: bolder; font-size: 11pt; color: green;"-->Nähmaschine<!-- style="font-weight: bolder; font-size: 11pt; color: green;"-->, auch Schnellnäher<!-- style="font-weight: bolder; font-size: 11pt; color: green;"--> genannt, ist ein zentrales Arbeitsmittel im Raumausstatterhandwerk.\
Sie wird für folgende Arbeitsgänge eingesetzt: 

<!-- class="hash"-->
- stabile Nähte an Stoffen
- Näharbeiten mit Leder und anderen dickeren Materialien

Der Schnellnäher gehört zu den wichtigsten<!-- style="font-weight: bolder; font-size: 11pt; color: green;"--> Maschinen<!-- style="font-weight: bolder; font-size: 11pt; color: green;"--> in der Polster<!-- style="font-weight: bolder; font-size: 11pt; color: green;"-->-<!-- style="font-weight: bolder; font-size: 11pt; color: green;"--> und Dekorationsarbeit<!-- style="font-weight: bolder; font-size: 11pt; color: green;"-->.

Mit diesem Quiz überprüfen Sie Ihr Wissen zu:

<!-- class="blueball"-->
- Aufbau
- Funktion
- Sicherheit
- richtige Bedienung


------------

<center>

![Polster-Naehmaschine](assets/images/b4bf8fb0b782bbcaa593ebd2f3471fd302a24e8c.jpg " _Foto: Kay Deblitz, HWK Dresden_")<!-- style="max-width: 250px; width: 100%" -->

</center>

## Geschichte & Bauformen


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Setzen Sie die passenden Wörter in die jeweiligen Felder im nachfolgenden Text.

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
Die Geschichte der Nähmaschinen beginnt im [->[  (19. Jahrhundert) | 18. Jahrhundert ]], als der Bedarf nach einer mechanischen Lösung für das Nähen von Stoffen immer größer wurde.

</div>
<div class="flex-child-2 center">

![alte_Naehmaschine](assets/images/ac58482dc666bb23b70c1b5d8f1f94a24cdf4727.jpg "_Quelle: HWK Dresden, Kay Deblitz_")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Bauformen sind typisch für Polsternähermaschinen?

<!-- style="font-weight: bolder; font-size: 10pt; color: #A00000;"-->
Es sind mehrere Antworten richtig!

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Flachbettmaschine
- [[X]] Säulenmaschine
- [[X]] Langarmmaschine
- [[ ]] Midi-Maschine
- [[ ]] Spindelarmmaschine
********************
Folgende Bauformen sind typisch:
- Flachbettmaschine
- Säulenmaschine
- Langarmmaschine
********************

</div>
<div class="flex-child-2 center">

![Frau in einer Textilfabrik hält einen Faden zwischen den Händen.](assets/images/148055bdf3467a0bb20a33d23c52f1e424fc85ca.jpg "Frau mit Faden in einer Textil- oder Nähfabrik. Bild von [prostooleh via Magnific](https://www.magnific.com/de/fotos-kostenlos/frau-steht-in-der-fabrik-mit-einem-faden_6633981.htm), kostenloses Foto.")<!-- style="max-width: 450px; width: 140%;  margin-left: -120px; margin-top: 30px;" -->

</div>
</section>

## Aufbau einer Polster-Nähmaschine - 1

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight"-->
Ordnen Sie die Maschinenbauteile 1 - 7 im Bild richtig zu.

<br>

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
1<!--style="color: blue; font-weight: bolder"-->  =  [[  Maschinenoberteil Kopf-Arm-Ständer | (Garnständer)   | Schubkasten |   Wickelmotor   | Aufnahmegerät   ]]
********************
1. Garnständer
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
2<!--style="color: blue; font-weight: bolder"-->  =  [[  Bedienteil |  Webboden   | Fußablage |   Steuerung der Nähgeschwindigkeit   | (Pedal)     ]]
********************
2. Pedal
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
3<!--style="color: blue; font-weight: bolder"-->  =  [[  Motorblock |   Nähtaster |  Garnmanschette  | Auszug für Tischverlängerung  |   (Schubkasten)   ]]
********************
3. Schubkasten
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
4<!--style="color: blue; font-weight: bolder"-->  =  [[ (Tischplatte) |  Mustertisch    | Nähauflage  |   Scherentisch   | Display    ]]
********************
4. Tischplatte
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
5<!--style="color: blue; font-weight: bolder"-->  =  [[  Musterdisplay |  Motorsteuerung    | Garnbox  |   (Bedienteil)    | Radio   ]]
********************
5. Bedienteil
********************



</div>
<div class="flex-child-2 center">
![Naehmanschine-Aufbau_klein](assets/images/e06859daf8c23bd92cb2a5e044ebbe0fd30b84c2.jpg " _Quelle: Kay Deblitz, HWK Dresden_")<!-- style="max-width: 550px; width: 150%; margin-left: -180px; margin-top: 30px;" -->


</div>
</section>



## Sicherheits- & Pflegeregeln

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Sicherheitsregeln sind beim Arbeiten an der Polster-Nähmaschine zu beachten?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [(X)] Vor Wartung Strom abschalten und auf Quetschungen achten
- [( )] Nadel regelmäßig anschleifen
- [( )] Schutzbrille nutzen
- [( )] Hände regelmäßig abtrocknen, z. B. mit Chalk 
********************
Bei Wartungsarbeiten an der Maschine ist immer der Strom abzuschalten oder der Netzstecker zu ziehen. Das Nähfüßchen kann sich manuell oder mechanisch bewegen und Quetschungen an Fingern verursachen. Die Nähmaschine verfügt über eine zentrale Ölschmierung. Dies führt dazu, dass Maschinenteile mit Öl behaftet sind. Ein Hautkontakt sollte mit diesen Teilen vermieden werden. Insbesondere vor dem Essen sind die Hände zu waschen.
********************

</div>
<div class="flex-child-2 center">

![Illustration mit verschiedenen Sicherheits- und Arbeitsschutzsymbolen, darunter Warn-, Hinweis-, Gebots-, Verbots-, Fluchtweg- und Brandschutzzeichen.](assets/images/93894f4a2c7a7c4fcb1e2cab8f278f2d7ea57a65.jpg "Übersicht verschiedener Sicherheits- und Arbeitsschutzzeichen. Bild von [succo via Pixabay](https://pixabay.com/illustrations/security-secure-protection-osh-1004655/), Pixabay Content License, veröffentlicht am 29. Oktober 2015.")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Pflege benötigt eine Polster-Nähmaschine?


<!-- style="font-weight: bolder; font-size: 10pt; color: #A00000;"-->
Es sind mehrere Antworten richtig!

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Regelmäßiges Ölen
- [[X]] Reinigung von Fusseln
- [[ ]] Anschleifen der Nadel
- [[ ]] Regelmäßige Software-Updates
********************
Um eine Polster-Nähmaschine gut zu pflegen, ist sie regelmäßig zu ölen und von Fusseln zu reinigen.
********************

</div>
</section>

## Materialien & Garne

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Materialien können mit Polster-Nähmaschinen verarbeitet werden?


<!-- style="font-weight: bolder; font-size: 10pt; color: #A00000;"-->
Es sind mehrere Antworten richtig!

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Leder
- [[X]] Möbelbezugsstoffe
- [[X]] Kunstleder
- [[ ]] Seide
- [[ ]] Jersey
********************
Mit einer Polster-Nähmaschine können Leder, Möbelbezugsstoffe und Kunstleder verarbeitet werden.
********************

</div>
<div class="flex-child-2 center">

![Nahaufnahme einer Nähmaschine, die hellen Stoff näht; im Vordergrund sind Nähfuß, Nadel und Stoffkante zu sehen.](assets/images/c5ef0e12df26de68c79b8323ecac51ad6e6659ec.jpg "Nähmaschine beim Nähen eines hellen Stoffes. Designed by [Freepik via Magnific](https://www.magnific.com/de/fotos-kostenlos/schneiderei-artikel-arrangement-stillleben_38306793.htm), kostenlose Ressource mit Namensnennung.")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Garnart wird verwendet?


<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [(X)] Polyester-Garn
- [( )] Baumwollstickgarn
- [( )] Seidengarn
- [( )] Wollfaden
********************
Für Näharbeiten mit der Polster-Nähmaschine werden nur Polyester-Garne verwendet
********************

</div>
<div class="flex-child-2 center">

![Nahaufnahme von gestapelten Garnrollen in verschiedenen Farben.](assets/images/6159cd02635dba529c0ce5ec0a42c6a7256c5396.jpg "Farbige Garnrollen als Motiv zum Thema Kleidung, Textil und Fast Fashion. Bild von [pikisuperstar via Magnific](https://www.magnific.com/de/fotos-kostenlos/sag-nein-zum-fast-fashion-konzept-mit-faden_38251967.htm), kostenloses Foto.")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>

## Bauteile einer Polster-Nähmaschine - 1

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight"-->
Ordnen Sie die Maschinenbauteile 1 - 5 im Bild richtig zu.

<br>

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
1<!--style="color: blue; font-weight: bolder"-->  =  [[  Maschinenoberteil Kopf-Arm-Ständer | (Garnständer)   | Schubkasten |   Wickelmotor   | Aufnahmegerät   ]]
********************
1. Garnständer
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
2<!--style="color: blue; font-weight: bolder"-->  =  [[  Bedienteil |  Webboden   | Fußablage |   Steuerung der Nähgeschwindigkeit   | (Pedal)     ]]
********************
2. Pedal
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
3<!--style="color: blue; font-weight: bolder"-->  =  [[  Motorblock |   Nähtaster |  Garnmanschette  | Auszug für Tischverlängerung  |   (Schubkasten)   ]]
********************
3. Schubkasten
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
4<!--style="color: blue; font-weight: bolder"-->  =  [[ (Tischplatte) |  Mustertisch    | Nähauflage  |   Scherentisch   | Display    ]]
********************
4. Tischplatte
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
5<!--style="color: blue; font-weight: bolder"-->  =  [[  Musterdisplay |  Motorsteuerung    | Garnbox  |   (Bedienteil)    | Radio   ]]
********************
5. Bedienteil
********************



</div>
<div class="flex-child-2 center">
![Naehmaschine_Teil1](assets/images/040883cf767c9be2f15cc257f41c8965f92e0c3e.png " _Quelle: Kay Deblitz, HWK Dresden_")<!-- style="max-width: 550px; width: 210%; margin-left: -180px; margin-top: 30px;" -->


</div>
</section>

## Fachgerechtes Einrichten


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Schritte gehören zum fachgerechten Einrichten der Maschine?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [(X)] Nähgarn aufspulen, Spule einlegen, Faden einfädeln und Spannung prüfen
- [( )] Inaugenscheinnahme der Maschine; wenn alles in Ordnung ist, kann der Faden eigefädelt, die Maschine gestartet und der Nähvorgang begonnen werden
- [( )] ggf. Öl auf der Tischfläche entfernen, Nadel wechseln, Faden einfädeln, Folgespule bereithalten
- [( )] Pedal- und Nähtischhöhe einstellen, Altgarn entsorgen, Faden einfädeln
********************
Zum fachgerechten Einrichten einer Nähmaschine gehören:
- Nähgarn aufspulen
- Spule einlegen
- Faden einfädeln
- Spannung prüfen
********************

</div>
<div class="flex-child-2 center">

![Stillleben mit Stoffstücken, Schneiderpapier, Garnrollen und einer Schneiderschere.](assets/images/4333cd17e76e2c355b9bfa4341055e69a67061f5.jpg "Schneiderei-Arrangement mit Stoff, Garn, Papier und Schere. Bild von [freepik via Magnific](https://www.magnific.com/de/fotos-kostenlos/schneiderei-artikel-arrangement-stillleben_38306699.htm), kostenloses Foto.")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>

### Wichtige Arbeitsabläufe


Sie sollen eine Nähmaschine einrichten. -- In welcher Reihenfolge führen Sie die einzelnen Arbeitsschritte aus?

<section class="flex-container border">
<div class="flex-child">


<!-- class="highlight"-->
Ziehen Sie die einzelnen Arbeitsschritte in die richtige Reihenfolge.\
An oberster Stelle steht der erste Arbeitsschritt.

<!-- data-randomize -->
@dragdroporder(@uid,Nähgarn auf Spule aufspulen|Spule in Spulenkapsel einlegen und Spannung einstellen|Spulenkapsel in Nähmaschine einsetzen|Oberfaden in Nähmaschine einfädeln und Unterfaden hochholen|Nähprobe|Oberfaden-Spannung einstellen und kontrollieren)


</div>
<div class="flex-child-0">

<br>

![Naehmaschine](assets/images/90f524b405dc55ed2df8c8864c4493e082ae7249.jpg " _Quelle: HWK Dresden, Kay Deblitz_")<!-- style="width: 500px;" -->


</div>
</section>

## Bauteile einer Polster-Nähmaschine - 2

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight"-->
Ordnen Sie die Maschinenbauteile 1 - 5\
im Bild richtig zu.

<br>

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
1<!--style="color: blue; font-weight: bolder"-->  =  [[  (Maschinenoberteil Kopf, Arm und Ständer) | Garnvorratsbehälter   | Schubkasten |   Gehäuse für Wickelmotor   | Schutzabdeckung   ]]
********************
1. Maschinenoberteil mit Kopf, Arm und Ständer
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
2<!--style="color: blue; font-weight: bolder"-->  =  [[  Bedienteil |  Programmierkasten   | Kasten mit Anschlüssen |   Ein-/Ausschaltknopf   | (Steuerung)     ]]
********************
2. Pedal
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
3<!--style="color: blue; font-weight: bolder"-->  =  [[  Motorblock |   Nähtaster |  Garnmanschette  | Auszug für Tischverlängerung  |   (Schubkasten)   ]]
********************
3. Schubkasten
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
4<!--style="color: blue; font-weight: bolder"-->  =  [[ (Tischplatte) |  Mustertisch    | Nähauflage  |   Scherentisch   | Display    ]]
********************
4. Tischplatte
********************

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
5<!--style="color: blue; font-weight: bolder"-->  =  [[  Musterdisplay |  Motorsteuerung    | Garnbox  |   (Bedienteil)    | Radio   ]]
********************
5. Bedienteil
********************



</div>
<div class="flex-child-2 center">
![Naehmaschine_Tl2](assets/images/f771b1365f72d7641bee2ae4572362db69108249.jpg " _Quelle: Kay Deblitz, HWK Dresden_")<!-- style="max-width: 500px; width: 170%; margin-left: -150px; margin-top:0px;" -->


</div>
</section>

## Sticharten & Nähnadeln


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Sticharten werden häufig genutzt?

<!-- style="font-weight: bolder; font-size: 10pt; color: #A00000;"-->
Es sind mehrere Antworten richtig!

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Geradstich
- [[X]] Doppelsteppstich
- [[ ]] Zierstich
- [[ ]] Kreuzstich
- [[ ]] Zick-Zack-Stich
********************
Es wird der Gerad- und Doppelsteppstich genutzt.
********************

</div>
<div class="flex-child-2 center">

![Nahaufnahme einer Nähmaschine, deren Nadel über hellen Stoff geführt wird.](assets/images/aa796974982e4399c11037fb4d280eefea9a4955.jpg "Nähmaschine beim Nähen eines hellen Stoffes. Bild von [freepik via Magnific](https://www.magnific.com/de/fotos-kostenlos/schneiderei-artikel-arrangement-stillleben_38306797.htm), kostenloses Foto.")<!-- style="max-width: 450px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Nadeln werden verwendet?

<!-- style="font-weight: bolder; font-size: 10pt; color: #A00000;"-->
Es sind mehrere Antworten richtig!

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Ledernadeln LR
- [[X]] Nadelstärke Nm120
- [[ ]] Stopfnadeln
- [[ ]] Nadelstärke Nm 70
- [[ ]] Stoffnadeln MM
********************
Es werden Ledernadeln LR und Nadeln mit einer Nadelstärke Nm 120 verwendet.
********************

</div>
<div class="flex-child-2 center">

![Nahaufnahme einer Nähmaschine, deren Nadel einen Stoff präzise näht.](assets/images/2981574d713e44ab1986275ff722a2328b895ff2.jpg "Nähmaschine beim präzisen Nähen eines Stoffes. Bild von [venturaartist via Pixabay](https://pixabay.com/photos/sewing-machine-sewing-precision-262454/), Pixabay Content License.")<!-- style="max-width: 450px; width: 150%; margin-left: -100px; margin-top:0px;" -->

</div>
</section>

## Super gemacht! 🙌


<center>
![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript-Courses/refs/heads/main/courses/img/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
</center>
